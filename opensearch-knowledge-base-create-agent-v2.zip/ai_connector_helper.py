import time
import json
import boto3
import logging
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth

# This Python code is compatible with AWS OpenSearch versions 2.9 and higher.
class AiConnectorHelper:
    def __init__(
        self,
        opensearch_region,
        opensearch_domain_url,
        aws_auth
    ):
        # singleton boto3 clients for opensearch
        self.opensearch_client = boto3.client("es", region_name=opensearch_region)

        self.aws_auth = aws_auth
        self.opensearch_domain_url = opensearch_domain_url
        
    
    def create_connector(self, payload):
        path = "/_plugins/_ml/connectors/_create"
        url = self.opensearch_domain_url + path

        headers = {"Content-Type": "application/json"}

        r = requests.post(url, auth=self.aws_auth, json=payload, headers=headers)
        print(r.text)
        connector_id = json.loads(r.text)["connector_id"]
        return connector_id


    def get_task(self, task_id):
        return requests.get(
            f"{self.opensearch_domain_url}/_plugins/_ml/tasks/{task_id}",
            auth=self.aws_auth,
        )

    def create_flow_agent_with_model(
        self, agent_name, description, model_id
    ):
        payload = {
          "name": "KB_For_Alert_Insight",
          "type": "flow",
          "description": description,
          "tools": [
            {
              "type": "MLModelTool",
              "name": "MLModelTool",
              "parameters": {
                "model_id": model_id
              }
            }
          ]
        }
        headers = {"Content-Type": "application/json"}
        r = requests.post(
            f"{self.opensearch_domain_url}/_plugins/_ml/agents/_register",
            auth=self.aws_auth,
            json=payload,
            headers=headers,
        )
        response = json.loads(r.text)
        if "agent_id" not in response:
            print("Failed to create agent")
        return response["agent_id"]
        

    def create_and_deploy_model(
        self, model_name, description, connector_id, deploy=True
    ):
        payload = {
            "name": model_name,
            "function_name": "remote",
            "description": description,
            "connector_id": connector_id
        }
        headers = {"Content-Type": "application/json"}
        deploy_str = str(deploy).lower()
        r = requests.post(
            f"{self.opensearch_domain_url}/_plugins/_ml/models/_register?deploy={deploy_str}",
            auth=self.aws_auth,
            json=payload,
            headers=headers,
        )
        print(r.text)
        response = json.loads(r.text)
        if "model_id" in response:
            return response["model_id"]
        else:
            time.sleep(2)  # sleep two seconds for task complete
            r = self.get_task(response["task_id"])
            print(r.text)
            return json.loads(r.text)["model_id"]

    def create_connector_with_role(
        self,
        create_connector_payload,
        sleep_time_in_seconds=10,
    ):
        # Create connector
        print("Step 1: Create connector in OpenSearch")
        # When you create an IAM role, it can take some time for the changes to propagate across AWS systems.
        # During this time, some services might not immediately recognize the new role or its permissions.
        # So we wait for some time before creating connector.
        # If you see such error: ClientError: An error occurred (AccessDenied) when calling the AssumeRole operation
        # you can rerun this function.

        # Wait for some time
        time.sleep(sleep_time_in_seconds)
        connector_id = self.create_connector(create_connector_payload)
        # print(connector_id)
        print("----------")
        return connector_id