import json
import requests
import boto3
from requests_aws4auth import AWS4Auth
from urllib.parse import urlparse
import cfnresponse
import time
from ai_connector_helper import AiConnectorHelper

def lambda_handler(event, context):
    print("Event:", event)
    request_type = event['RequestType']

    opensearch_domain_url = event["ResourceProperties"]["AmazonOpenSearchDomainEndpoint"]
    knowledge_base_id = event["ResourceProperties"]["KnowledgeBaseId"]
    connector_role_arn = event["ResourceProperties"]["ConnectorRoleArn"]
    llm_arn = event["ResourceProperties"]["LlmArn"]

    aws_auth = create_aws_auth(context)
    aiConnectorHelper = AiConnectorHelper(
        opensearch_region = aos_region, 
        opensearch_domain_url = opensearch_domain_url,
        aws_auth = aws_auth
    )
    
    create_connector_payload = get_create_connector_payload(
        llm_arn = llm_arn,
        knowledge_base_id = knowledge_base_id,
        connector_role_arn = connector_role_arn,
        knowledge_base_region = knowledge_base_region
    )
    
    connector_id = aiConnectorHelper.create_connector_with_payload(
        create_connector_payload = create_connector_payload,
    )
    print("connector_id:", connector_id)
    
    model_id = aiConnectorHelper.create_and_deploy_model(
        model_name = "KB_For_Alert_Insight",
        description = "KB_For_Alert_Insight",
        connector_id = connector_id
    )
    print("model_id:", model_id)
    
    agent_id = aiConnectorHelper.create_flow_agent_with_model(
        agent_name = "KB_For_Alert_Insight",
        description = "KB_For_Alert_Insight",
        model_id = model_id
    )
    print("agent_id:", agent_id)
    
    response_data = {
        "connector_id": connector_id,
        "model_id": model_id,
        "agent_id": agent_id
    }

    return respond_to_cloudformation(event, context, cfnresponse.SUCCESS, response_data)

def create_aws_auth(context):
    region = context.invoked_function_arn.split(':')[3]
    service = 'es'
    session = boto3.Session()
    credentials = session.get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    return awsauth

def get_aws_account_id():
    sts_client = boto3.client("sts")
    response = sts_client.get_caller_identity()
    return response['Account']
    
def get_create_connector_payload(connector_role_arn, knowledge_base_region, knowledge_base_id, llm_arn):
    return {
      "name": "Amazon Bedrock Connector: knowledge",
      "description": "The connector to the Bedrock knowledge base",
      "version": 1,
      "protocol": "aws_sigv4",
      "credential": {
        "roleArn": connector_role_arn
      },
      "parameters": {
        "region": knowledge_base_region,
        "service_name": "bedrock",
        "knowledgeBaseId": knowledge_base_id,
        "model_arn": llm_arn
      },
      "actions": [
        {
          "action_type": "predict",
          "method": "POST",
          "url": f"https://bedrock-agent-runtime.{knowledge_base_region}.amazonaws.com/retrieveAndGenerate",
          "headers": {
            "content-type": "application/json"
          },
          "request_body": """{"input": {"text": "${parameters.text}"}, "retrieveAndGenerateConfiguration": {"type": "KNOWLEDGE_BASE", "knowledgeBaseConfiguration": {"knowledgeBaseId": "${parameters.knowledgeBaseId}", "modelArn": "${parameters.model_arn}"}}}""",
          "post_process_function": "return params.output.text;"
        }
      ]
    }

def respond_to_cloudformation(event, context, response_status, response_data, reason=None):
    response_data['model_endpoint'] = response_data.get('model_endpoint', "")
    response_data['connector_id'] = response_data.get('connector_id', "")
    response_data['model_id'] = response_data.get('model_id', "")
    cfnresponse.send(event, context, response_status, response_data, context.log_stream_name, reason)
    return {"statusCode": 200 if response_status == cfnresponse.SUCCESS else 500, "body": json.dumps(response_data)}
