import time
import json
import boto3
import logging
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth

# This Python code is compatible with AWS OpenSearch versions 2.9 and higher.
class AiConnectorHelper:
    def __init__(
        self,
        opensearch_region,
        opensearch_domain_url,
        aws_auth
    ):
        # singleton boto3 clients for opensearch, iam and sts
        self.opensearch_client = boto3.client("es", region_name=opensearch_region)
        self.iam_client = boto3.client("iam")
        self.sts_client = boto3.client("sts")

        self.aws_auth = aws_auth
        self.opensearch_region = opensearch_region
        self.opensearch_domain_url = opensearch_domain_url
        

    def get_user_arn(self, username):
        try:
            # Get information about the IAM user
            response = self.iam_client.get_user(UserName=username)
            user_arn = response["User"]["Arn"]
            print("user_arn:", user_arn, "username:", username)
            return user_arn
        except self.iam_client.exceptions.NoSuchEntityException:
            logging.error(f"IAM user '{username}' not found.")
            return None

    def role_exists(self, role_name):
        try:
            self.iam_client.get_role(RoleName=role_name)
            return True
        except self.iam_client.exceptions.NoSuchEntityException:
            return False

    def create_iam_role(self, role_name, trust_policy_json, policy_json):
        try:
            # Create the role with the trust policy
            create_role_response = self.iam_client.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(trust_policy_json),
                Description="Role with custom trust and inline policies",
            )

            # Get the ARN of the newly created role
            role_arn = create_role_response["Role"]["Arn"]

            # Attach the inline policy to the role
            self.iam_client.put_role_policy(
                RoleName=role_name,
                PolicyName="KnowledgeBasePolicy",
                PolicyDocument=json.dumps(policy_json),
            )

            print(f"Created role: {role_name}")
            return role_arn

        except Exception as e:
            logging.error(f"Error creating the role: {e}")
            return None

    def get_role_arn(self, role_name):
        try:
            response = self.iam_client.get_role(RoleName=role_name)
            # Return ARN of the role
            return response["Role"]["Arn"]
        except self.iam_client.exceptions.NoSuchEntityException:
            logging.error(f"The requested role {role_name} does not exist")
            return None
        except Exception as e:
            logging.error(f"An error occurred: {e}")
            return None

    def assume_role(
        self, create_connector_role_arn, role_session_name="your_session_name"
    ):
        # role_arn = f"arn:aws:iam::{aws_account_id}:role/{role_name}"
        print("create_connector_role_arn:", create_connector_role_arn)
        assumed_role_object = self.sts_client.assume_role(
            RoleArn=create_connector_role_arn,
            RoleSessionName=role_session_name,
        )
        print("assumed_role_object:", assumed_role_object)

        # Obtain the temporary credentials from the assumed role
        temp_credentials = assumed_role_object["Credentials"]

        return temp_credentials

    def create_connector(self, payload):
        path = "/_plugins/_ml/connectors/_create"
        url = self.opensearch_domain_url + path

        headers = {"Content-Type": "application/json"}

        r = requests.post(url, auth=self.aws_auth, json=payload, headers=headers)
        print(r.text)
        connector_id = json.loads(r.text)["connector_id"]
        return connector_id


    def get_task(self, task_id):
        return requests.get(
            f"{self.opensearch_domain_url}/_plugins/_ml/tasks/{task_id}",
            auth=self.aws_auth,
        )

    def create_flow_agent_with_model(
        self, agent_name, description, model_id
    ):
        payload = {
          "name": "Test_Agent_For_Knowledge_Base",
          "type": "flow",
          "description": description,
          "tools": [
            {
              "type": "MLModelTool",
              "name": "MLModelTool",
              "parameters": {
                "model_id": model_id
              }
            }
          ]
        }
        headers = {"Content-Type": "application/json"}
        r = requests.post(
            f"{self.opensearch_domain_url}/_plugins/_ml/agents/_register",
            auth=self.aws_auth,
            json=payload,
            headers=headers,
        )
        response = json.loads(r.text)
        if "agent_id" not in response:
            print("Failed to create agent")
        return response["agent_id"]
        

    def create_and_deploy_model(
        self, model_name, description, connector_id, deploy=True
    ):
        payload = {
            "name": model_name,
            "function_name": "remote",
            "description": description,
            "connector_id": connector_id
        }
        headers = {"Content-Type": "application/json"}
        deploy_str = str(deploy).lower()
        r = requests.post(
            f"{self.opensearch_domain_url}/_plugins/_ml/models/_register?deploy={deploy_str}",
            auth=self.aws_auth,
            json=payload,
            headers=headers,
        )
        print(r.text)
        response = json.loads(r.text)
        if "model_id" in response:
            return response["model_id"]
        else:
            time.sleep(2)  # sleep two seconds for task complete
            r = self.get_task(response["task_id"])
            print(r.text)
            return json.loads(r.text)["model_id"]

    def create_connector_with_role(
        self,
        connector_role_name,
        connector_role_policy,
        create_connector_payload,
        sleep_time_in_seconds=10,
    ):
        
        # Step1: Create IAM role configued in connector
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "es.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ]
        }

        print("Step1: Create IAM role configued in connector")
        if not self.role_exists(connector_role_name):
            connector_role_arn = self.create_iam_role(
                connector_role_name, trust_policy, connector_role_policy
            )
        else:
            print("role exists, skip creating")
            connector_role_arn = self.get_role_arn(connector_role_name)
        # print(connector_role_arn)
        print("----------")

        # 2. Create connector
        print("Step 2: Create connector in OpenSearch")
        # When you create an IAM role, it can take some time for the changes to propagate across AWS systems.
        # During this time, some services might not immediately recognize the new role or its permissions.
        # So we wait for some time before creating connector.
        # If you see such error: ClientError: An error occurred (AccessDenied) when calling the AssumeRole operation
        # you can rerun this function.

        # Wait for some time
        time.sleep(sleep_time_in_seconds)
        payload = create_connector_payload
        payload["credential"] = {"roleArn": connector_role_arn}
        connector_id = self.create_connector(payload)
        # print(connector_id)
        print("----------")
        return connector_id