import json
import requests
import boto3
from requests_aws4auth import AWS4Auth
from urllib.parse import urlparse
import cfnresponse
import time
from ai_connector_helper import AiConnectorHelper

def lambda_handler(event, context):
    print("Event:", event)
    request_type = event['RequestType']
    
    if request_type in ['Update', 'Delete']:
        return respond_to_cloudformation(event, context, cfnresponse.SUCCESS, {})

    aos_region = event["ResourceProperties"]["AmazonOpenSearchRegion"]
    opensearch_domain_url = event["ResourceProperties"]["AmazonOpenSearchDomainEndpoint"]
    knowledge_base_region = event["ResourceProperties"]["KnowledgeBaseRegion"]
    knowledge_base_id = event["ResourceProperties"]["KnowledgeBaseId"]
    llm_arn = event["ResourceProperties"]["LlmArn"]
    knowledge_base_connector_role_name = "create_knowledge_base_connector"
    
    aws_auth = create_aws_auth(context)
    aiConnectorHelper = AiConnectorHelper(
        opensearch_region = aos_region, 
        opensearch_domain_url = opensearch_domain_url,
        aws_auth = aws_auth
    )

    connector_role_policy = get_connector_role_policy(
        knowledge_base_region = knowledge_base_region,
        knowledge_base_id = knowledge_base_id,
        llm_arn = llm_arn
    )
    
    create_connector_payload = get_create_connector_payload(
        knowledge_base_region = knowledge_base_region,
        knowledge_base_id = knowledge_base_id,
        llm_arn = llm_arn
    )
    
    
    connector_id = aiConnectorHelper.create_connector_with_role(
        connector_role_name = knowledge_base_connector_role_name,
        connector_role_policy = connector_role_policy,
        create_connector_payload = create_connector_payload,
    )
    print("connector_id:", connector_id)
    
    model_id = aiConnectorHelper.create_and_deploy_model(
        model_name = "knowledge_base_model",
        description = "knowledge_base_model",
        connector_id = connector_id
    )
    print("model_id:", model_id)
    
    agent_id = aiConnectorHelper.create_flow_agent_with_model(
        agent_name = "knowledge_base_agent",
        description = "knowledge_base_agent",
        model_id = model_id
    )
    print("agent_id:", agent_id)
    
    response_data = {
        "connector_id": connector_id,
        "model_id": model_id,
        "agent_id": agent_id
    }

    return respond_to_cloudformation(event, context, cfnresponse.SUCCESS, response_data)

def create_aws_auth(context):
    region = context.invoked_function_arn.split(':')[3]
    service = 'es'
    session = boto3.Session()
    credentials = session.get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    return awsauth

def get_aws_account_id():
    sts_client = boto3.client("sts")
    response = sts_client.get_caller_identity()
    return response['Account']

def get_connector_role_policy(knowledge_base_region, knowledge_base_id, llm_arn):
    aws_account_id = get_aws_account_id()
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "BedrockKnowledgeBaseAPI",
                "Effect": "Allow",
                "Action": [
                    "bedrock:Retrieve",
                    "bedrock:RetrieveAndGenerate"
                ],
                "Resource": [
                    f"arn:aws:bedrock:{knowledge_base_region}:{aws_account_id}:knowledge-base/{knowledge_base_id}"
                ]
            },
            {
                "Sid": "BedrockInvokeLLMAPI",
                "Effect": "Allow",
                "Action": [
                    "bedrock:InvokeModel"
                ],
                "Resource": [
                    llm_arn
                ]
            }
        ]
    }
    
def get_create_connector_payload(knowledge_base_region, knowledge_base_id, llm_arn):
    return {
      "name": "Amazon Bedrock Connector: knowledge",
      "description": "The connector to the Bedrock knowledge base",
      "version": 1,
      "protocol": "aws_sigv4",
      "parameters": {
        "region": knowledge_base_region,
        "service_name": "bedrock",
        "knowledgeBaseId": knowledge_base_id,
        "model_arn": llm_arn
      },
      "actions": [
        {
          "action_type": "predict",
          "method": "POST",
          "url": f"https://bedrock-agent-runtime.{knowledge_base_region}.amazonaws.com/retrieveAndGenerate",
          "headers": {
            "content-type": "application/json"
          },
          "request_body": """{"input": {"text": "${parameters.text}"}, "retrieveAndGenerateConfiguration": {"type": "KNOWLEDGE_BASE", "knowledgeBaseConfiguration": {"knowledgeBaseId": "${parameters.knowledgeBaseId}", "modelArn": "${parameters.model_arn}"}}}""",
          "post_process_function": "return params.output.text;"
        }
      ]
    }

def respond_to_cloudformation(event, context, response_status, response_data, reason=None):
    response_data['model_endpoint'] = response_data.get('model_endpoint', "")
    response_data['connector_id'] = response_data.get('connector_id', "")
    response_data['model_id'] = response_data.get('model_id', "")
    cfnresponse.send(event, context, response_status, response_data, context.log_stream_name, reason)
    return {"statusCode": 200 if response_status == cfnresponse.SUCCESS else 500, "body": json.dumps(response_data)}
